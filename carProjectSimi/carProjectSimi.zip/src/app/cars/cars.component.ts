import { Component,Input } from '@angular/core';
import { Car } from '../services/car.service'; 
@Component({
  selector: 'app-cars',
  standalone: true,
  imports: [],
  templateUrl: './cars.component.html',
  styleUrl: './cars.component.css'
})
export class CarsComponent {
 @Input() car: Car | null = null;
}
