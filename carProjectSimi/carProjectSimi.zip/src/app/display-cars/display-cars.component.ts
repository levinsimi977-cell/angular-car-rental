import { Component } from '@angular/core';
import { CarsComponent } from '../cars/cars.component';
import { Car, CarService } from '../services/car.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-display-cars',
  standalone: true,
  imports: [CarsComponent, CommonModule, FormsModule],
  templateUrl: './display-cars.component.html',
  styleUrl: './display-cars.component.css'
})
export class DisplayCarsComponent {

  arr: Car[] = [];
  filteredCars: Car[] = [];

  // שדות סינון
  selectedSeats: number | null = null;
  selectedGear: string = '';
  maxPrice: number | null = null;
  selectedLevel: number | null = null;
  selectedFilter: string = ''; // סוג הסינון שנבחר

  constructor(private service: CarService) {
    this.loadCars();
  }

  // טוען את כל הרכבים
  loadCars() {
    this.service.getCarsList().subscribe(cars => {
      this.arr = cars;
      this.filteredCars = cars;
    });
  }

  // מפעיל את הסינון
  applyFilters() {
  let level = this.selectedLevel;
  let price = this.maxPrice;
  let seats = this.selectedSeats;

  // לשלוח את הסינון המתאים על פי סוג הסינון שנבחר
  if (this.selectedFilter === 'seats' && seats !== null) {
    this.service.getCarsBySeats(seats).subscribe(filteredCars => {
      this.filteredCars = filteredCars;
    });
  } else if (this.selectedFilter === 'price' && price !== null) {
    this.service.getCarsByPriceForDay(price).subscribe(filteredCars => {
      this.filteredCars = filteredCars;
    });
  } else if (this.selectedFilter === 'level' && level !== null) {
    this.service.getCarsByLevel(level).subscribe(filteredCars => {
      this.filteredCars = filteredCars;
    });
  } else {
    this.filteredCars = this.arr;
  }
}

  // מאפס את הסינונים
  resetFilters() {
    this.selectedSeats = null;
    this.selectedGear = '';
    this.maxPrice = null;
    this.selectedLevel = null;
    this.selectedFilter = '';
    this.filteredCars = this.arr;
  }

  // פונקציה שתבצע פעולה בהתאם לסוג הסינון שנבחר
  onFilterChange() {
    this.applyFilters();
  }
}