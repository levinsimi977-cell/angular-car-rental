import { Component } from '@angular/core';
import { CustomerService } from '../services/customer.service'; // ה ייבוא- service
import { RouterOutlet } from '@angular/router';
import { DisplayCarsComponent } from '../display-cars/display-cars.component';
import { FormsModule } from '@angular/forms';
import { Customer } from '../services/customer.service'; // הלקוח של הממשק ייבוא
import { CommonModule } from '@angular/common'; // הוספת CommonModule
import { Router } from '@angular/router';
import { RouterLink, RouterLinkActive} from '@angular/router'; // הוספת RouterLink ו-RouterLinkActive
@Component({
selector: 'app-login',
standalone: true,
imports: [RouterOutlet, FormsModule, CommonModule,RouterLink, RouterLinkActive],
templateUrl: './login.component.html',
styleUrl: './login.component.css',

})


export class LoginComponent {
title = 'car-client';
customer: Customer | null = null;
errorMessage: string = '';
showModal: boolean = false;
newCustomer: Customer = {
Id: 0,
firstName: '',
lastName: '',
email: '',
address: '',
numRents: 0,
codePayment: 1,
codeCity: 1,
City: null,
Payment: null
};
constructor(private customerService: CustomerService, private router: Router) {} // הזרקת
resetForm() {
this.newCustomer = {
Id:0,
firstName: '',
lastName: '',
email: '',
address: '',
numRents: 0,
codePayment: 1,
codeCity: 1,
City: null,
Payment: null
};
}
checkId() {
const userId = (<HTMLInputElement>document.getElementById('userId')).value;
if (!userId) {
this.errorMessage = 'Please enter a valid ID.';
return;
}
this.customerService.getCustomerById(Number(userId)).subscribe({
next: (customer) => {
if(customer){
this.customer = customer;
this.errorMessage = '';
alert('Customer found : ' + customer.firstName + ' ' + customer.lastName);
localStorage.setItem('userName', customer.firstName);
this.router.navigate(['/dashboard']);
} else {


this.showModal = true;
}
},
error: (error) => {
this.errorMessage = 'Customer not found.';
this.customer = null;
this.showModal = true;
}
});
}
closeModal() {
this.showModal = false;
this.resetForm();
}
submitNewCustomer() {
const customerToSend = {
Id: this.newCustomer.Id,
firstName: this.newCustomer.firstName,
lastName: this.newCustomer.lastName,
email: this.newCustomer.email,
address: this.newCustomer.address,
numRents: this.newCustomer.numRents || 0,
codeCity: 1,
codePayment: 1
};
this.customerService.insertNewCustomer(customerToSend as any).subscribe({
next: (response) => {
alert('!הלקוח נוסף בהצלחה');
this.showModal = false;
this.resetForm();
localStorage.setItem('userName', customerToSend.firstName);
this.router.navigate(['/dashboard']);
},
error: (err) => {
console.error('בשרת שגיאה:', err);
if (err.status === 200) {
alert('111');
this.showModal = false;
this.resetForm();
} else {
alert('לקוח בהוספת שגיאה: ' +( err.error?.message || err.message));
}
}
});
}
}